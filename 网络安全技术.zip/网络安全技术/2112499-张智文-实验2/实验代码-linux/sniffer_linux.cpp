#include <iostream>
#include <cstring>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <unistd.h>
#include <netdb.h>
#include <netinet/ip.h>
#include <netinet/tcp.h>
#include <netinet/udp.h>
#include <netinet/ip_icmp.h>

using namespace std;

const int BUFFER_SIZE = 65535;

// IP分组首部构造
struct IPHeader {
    unsigned char iphVerLen;            // 版本号和头长度
    unsigned char ipTOS;                // 服务类型
    unsigned short ipLength;            // 总长度
    unsigned short ipID;                // 标识符
    unsigned short ipFlags;             // 标志
    unsigned char ipTTL;                // 生存时间
    unsigned char ipProtocol;           // 协议类型：TCP/UDP/ICMP
    unsigned short ipChecksum;          // 校验和
    unsigned long ipSource;             // 源ip地址
    unsigned long ipDestination;        // 目的ip地址
};

// ICMP 包头构造
struct ICMPHeader {
    char i_type;                        // ICMP包类型码
    char i_code;                        // 代码
    unsigned short i_cksum;             // 校验和
    unsigned short i_id;                // 标识符，一般为发送进程的ID
    unsigned short i_seq;               // 序列号
    unsigned long timestamp;            // 时间戳
};

// UDP包头
struct UDPHeader {
    unsigned short sourcePort;          // 源端口号
    unsigned short destinationPort;     // 目的端口号
    unsigned short len;                 // 数据报长度
    unsigned short checksum;            // 校验和
};

// TCP包头
struct TCPHeader {
    unsigned short sourcePort;          // 16位源端口号
    unsigned short destinationPort;     // 16位目的端口号
    unsigned long seq;                  // 32位序列号
    unsigned long ack;                  // 32位ack
    char dataoffset;                    // 高四位表示数据偏移
    char flags;                         // 低六位为urg ack psh rst syn fin 共六个标识位
    unsigned short windows;             // 16位窗口大小
    unsigned long checksum;             // 16位校验和
    unsigned short urgentPointer;       // 16位紧急数据偏移量
};

// TCP包解析函数
void TCP_analyze(char* pData) {
    TCPHeader* pTCPHdr = (TCPHeader*)pData;
    cout << "TCP源端口号：" << ntohs(pTCPHdr->sourcePort) << "\t";
    cout << "目的端口号：" << ntohs(pTCPHdr->destinationPort) << endl;
    cout << "序列号seq：" << ntohl(pTCPHdr->seq) << "\t";
    cout << "确认号ack：" << ntohl(pTCPHdr->ack) << endl;
    cout << "\n";
}

// UDP包解析函数
void UDP_analyze(char* pData) {
    UDPHeader* pUDPHdr = (UDPHeader*)pData;
    cout << "UDP源端口号：" << ntohs(pUDPHdr->sourcePort) << "\t";
    cout << "目的端口号：" << ntohs(pUDPHdr->destinationPort) << endl;
    cout << "数据报长度：" << ntohs(pUDPHdr->len) << endl;
    cout << "\n";
}

// ICMP包解析函数
void ICMP_analyze(char* pData) {
    ICMPHeader* pICMPHdr = (ICMPHeader*)pData;
    cout << "ICMP Type :" << (int)pICMPHdr->i_type << " Code: " << (int)pICMPHdr->i_code << " ";
    switch (pICMPHdr->i_type) {
    case 0:
        cout << "Echo Response.\n";
        break;
    case 8:
        cout << "Echo Request.\n";
        break;
    case 3:
        cout << "Destination Unreachable.\n";
        break;
    case 11:
        cout << "Datagram Timeout (TTL = 0).\n";
        break;
    }
    cout << "\n";
}

// IP分组解析函数
void IP_analyze(char* pData) {
    IPHeader* pIPHdr = (IPHeader*)pData;
    struct in_addr source, dest;
    source.s_addr = pIPHdr->ipSource;
    dest.s_addr = pIPHdr->ipDestination;
    cout << "源IP：" << inet_ntoa(source) << "\t";
    cout << "目的IP：" << inet_ntoa(dest) << endl;
    int nHeaderlen = (pIPHdr->iphVerLen & 0xf) * sizeof(unsigned long); // ip头长度
    switch (pIPHdr->ipProtocol) {
    case IPPROTO_TCP:
        cout << "捕获到TCP包：" << endl;
        TCP_analyze((char*)pData + nHeaderlen);
        break;
    case IPPROTO_UDP:
        cout << "捕获到UDP包：" << endl;
        UDP_analyze((char*)pData + nHeaderlen);
        break;
    case IPPROTO_ICMP:
        cout << "捕获到ICMP包：" << endl;
        ICMP_analyze((char*)pData + nHeaderlen);
        break;
    default:
        cout << "其他协议类型：" << (int)pIPHdr->ipProtocol << endl;
    }
}

// 过滤器和用户输入
void filter(int& protocol, unsigned long& destIP) {
    cout << "请输入要捕获的协议类型 (TCP：6, UDP：17, ICMP：1，all：0)：";
    cin >> protocol;

    cout << "请输入要捕获的目的IP地址 (输入0代表所有地址)：";
    char destIPStr[20];
    cin >> destIPStr;
    if (strcmp(destIPStr, "0") == 0) {
        destIP = 0;
    } else {
        destIP = inet_addr(destIPStr);
    }
}

int main() {
    int sock = socket(AF_INET, SOCK_RAW, IPPROTO_TCP);
    if (sock < 0) {
        perror("Socket creation failed");
        return -1;
    }

    int protocol;
    unsigned long destIP;
    filter(protocol, destIP);

    struct sockaddr_in saddr;
    int saddr_len = sizeof(saddr);

    char buffer[BUFFER_SIZE];
    while (true) {
        int data_size = recvfrom(sock, buffer, BUFFER_SIZE, 0, (struct sockaddr *)&saddr, (socklen_t *)&saddr_len);
        if (data_size < 0) {
            perror("Recvfrom error");
            continue;
        }
        IPHeader* ipHdr = (IPHeader*)buffer;
        if ((protocol == 0 || ipHdr->ipProtocol == protocol) &&
            (destIP == 0 || ipHdr->ipDestination == destIP)) {
            IP_analyze(buffer);
        }
    }

    close(sock);
    return 0;
}