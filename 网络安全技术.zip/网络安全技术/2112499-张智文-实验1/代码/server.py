import socket
import threading
import datetime
from Crypto.Cipher import AES
from Crypto.Util.Padding import unpad, pad
from Crypto.Signature import pkcs1_15
from Crypto.Hash import SHA256
from Crypto.PublicKey import RSA
import base64

client_sockets = []
client_addresses = []

# 16进制字符串表示的key和iv
key_hex = 'b64f97d7397e156e51bd0b7c4fe22a6f'
iv_hex = '1ba0c89fda75bb1a0b1cb5e0c2cf7c90'

# 将16进制字符串转换为字节对象
key = bytes.fromhex(key_hex)
iv = bytes.fromhex(iv_hex)

def encrypt_message(message):
    cipher = AES.new(key, AES.MODE_CBC, iv)
    encrypted_message = cipher.encrypt(pad(message.encode('utf-8'), AES.block_size))
    return base64.b64encode(encrypted_message).decode('utf-8')

def decrypt_message(encrypted_message):
    cipher = AES.new(key, AES.MODE_CBC, iv)
    decrypted_message = unpad(cipher.decrypt(base64.b64decode(encrypted_message)), AES.block_size)
    return decrypted_message.decode('utf-8')

# 加载公钥
with open("public.pem", "rb") as pub_file:
    public_key = RSA.import_key(pub_file.read())

def verify_signature(encrypted_message, signature_b64):
    """验证接收到的消息的签名"""
    signature = base64.b64decode(signature_b64)
    h = SHA256.new(encrypted_message)
    try:
        pkcs1_15.new(public_key).verify(h, signature)
        return True
    except (ValueError, TypeError):
        return False
    
# 假设服务器的私钥加载如下
with open("server_private.pem", "rb") as prv_file:
    server_private_key = RSA.import_key(prv_file.read())

def sign_message(encrypted_message):
    """对加密后的消息进行签名"""
    h = SHA256.new(encrypted_message)
    signature = pkcs1_15.new(server_private_key).sign(h)
    return base64.b64encode(signature).decode('utf-8')


def get_current_time():
    return datetime.datetime.now().strftime("%H:%M:%S")


def handle_client(client_socket, client_address, client_index):
    while True:
        try:
            message_with_signature = client_socket.recv(1048576).decode('utf-8')
            if message_with_signature == "quit":
                exit_msg = f"quit：{current_time} : User {client_index}退出了聊天室"
                print(exit_msg)
                for i, sock in enumerate(client_sockets):
                    if i != client_index:
                        sock.sendall(exit_msg.encode('utf-8'))
                client_socket.close()
                client_sockets.pop(client_index)
                client_addresses.pop(client_index)
                break

            if message_with_signature != "quit":
                signature_b64, encrypted_message_b64 = message_with_signature.split(':')
                encrypted_message = base64.b64decode(encrypted_message_b64)
                
                # 验签
                if verify_signature(encrypted_message, signature_b64):
                    print("签名认证成功")
                    message = decrypt_message(encrypted_message_b64)
                    current_time = get_current_time()
                    print(f"{current_time} : User {client_index}发送的消息的密文：{encrypted_message}")
                    
                    # 准备要广播的消息
                    broadcast_message = f"{current_time} : User {client_index} 发送消息： {message}"
                    encrypted_broadcast_message = encrypt_message(broadcast_message)
                    signature_b64 = sign_message(encrypted_broadcast_message.encode('utf-8'))
                    
                    # 将签名和加密后的消息一起发送给其他客户端
                    message_to_send = f"{signature_b64}:{base64.b64encode(encrypted_broadcast_message.encode('utf-8')).decode('utf-8')}"
                    for i, sock in enumerate(client_sockets):
                        if i != client_index:
                            sock.sendall(message_to_send.encode('utf-8'))
                else:
                    print("签名验证失败")
            else:
                break
        except ConnectionResetError:
            break
        except Exception as e:
            print(f"处理客户端消息时发生错误: {e}")
            break

def main():
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server_socket.bind(('127.0.0.1', 12345))
    server_socket.listen(10)
    print("聊天室服务器已启动")

    while True:
        client_socket, client_address = server_socket.accept()
        client_index = len(client_sockets)
        client_sockets.append(client_socket)
        client_addresses.append(client_address)
        print(f"{get_current_time()} : User {client_index}进入了聊天室")
        threading.Thread(target=handle_client, args=(client_socket, client_address, client_index)).start()

if __name__ == "__main__":
    main()
