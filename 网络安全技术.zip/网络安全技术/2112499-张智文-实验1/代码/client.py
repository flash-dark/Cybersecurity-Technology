import socket
import threading
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad, unpad
import base64
from Crypto.Signature import pkcs1_15
from Crypto.Hash import SHA256
from Crypto.PublicKey import RSA

# 加载私钥和公钥
with open("private.pem", "rb") as prv_file:
    private_key = RSA.import_key(prv_file.read())

with open("server_public.pem", "rb") as pub_file:
    public_key = RSA.import_key(pub_file.read())

def sign_message(encrypted_message):
    """对加密后的消息进行签名"""
    h = SHA256.new(encrypted_message)
    signature = pkcs1_15.new(private_key).sign(h)
    return base64.b64encode(signature).decode('utf-8')

def verify_signature(encrypted_message, signature_b64):
    """验证接收到的消息的签名"""
    signature = base64.b64decode(signature_b64)
    h = SHA256.new(encrypted_message)
    try:
        pkcs1_15.new(public_key).verify(h, signature)
        return True
    except (ValueError, TypeError):
        return False

# 16进制字符串表示的key和iv
key_hex = 'b64f97d7397e156e51bd0b7c4fe22a6f'
iv_hex = '1ba0c89fda75bb1a0b1cb5e0c2cf7c90'

# 将16进制字符串转换为字节对象
key = bytes.fromhex(key_hex)
iv = bytes.fromhex(iv_hex)

# 确保encrypt_message函数返回的是未编码的加密消息
def encrypt_message(message):
    cipher = AES.new(key, AES.MODE_CBC, iv)
    encrypted_message = cipher.encrypt(pad(message.encode('utf-8'), AES.block_size))
    return encrypted_message  # 直接返回加密后的字节对象

def decrypt_message(encrypted_message):
    cipher = AES.new(key, AES.MODE_CBC, iv)
    decrypted_message = unpad(cipher.decrypt(base64.b64decode(encrypted_message)), AES.block_size)
    return decrypted_message.decode('utf-8')

# 接收消息，解密，验签
def receive_messages(client_socket):
    while True:
        try:
            encrypted_message_with_signature = client_socket.recv(1048576).decode('utf-8')
            if not encrypted_message_with_signature:
                print("服务器关闭了连接")
                break

            if encrypted_message_with_signature.startswith("quit"):
                print(encrypted_message_with_signature)
            
            else:
                # 分离签名和加密后的消息
                signature_b64, encrypted_message_b64 = encrypted_message_with_signature.split(':')
                encrypted_message = base64.b64decode(encrypted_message_b64)
            
                # 验证签名
                if verify_signature(encrypted_message, signature_b64):
                    print("签名认证成功")
                    # 解密消息
                    message = decrypt_message(encrypted_message)
                    print(f"收到的消息：{message}")
                else:
                    print("签名验证失败")
                
        except Exception as e:
            print(f"接收消息时出错: {e}")
            break

def main():
    try:
        client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        server_address = ('127.0.0.1', 12345)
        client_socket.connect(server_address)
        print("成功连接到聊天室服务器，下面可以发送消息")

        # 创建并启动接收消息的线程
        threading.Thread(target=receive_messages, args=(client_socket,), daemon=True).start()

        while True:
            message = input()
            if message == "quit":
                client_socket.sendall(message.encode('utf-8'))
                print("你已退出聊天室")
                break
            
            # 加密消息
            encrypted_message = encrypt_message(message)
            print(f"加密后的消息：{encrypted_message}")
            encrypted_message_b64 = base64.b64encode(encrypted_message).decode('utf-8')
            
            # 对加密后的消息进行签名
            signature_b64 = sign_message(encrypted_message)
            
            # 将签名和加密后的消息一起发送
            message_to_send = f"{signature_b64}:{encrypted_message_b64}"
            print(f"加密并签名后的消息：{message_to_send}")
            client_socket.sendall(message_to_send.encode('utf-8'))

    except Exception as e:
        print(f"连接到服务器失败: {e}")
    finally:
        client_socket.close()

if __name__ == "__main__":
    main()