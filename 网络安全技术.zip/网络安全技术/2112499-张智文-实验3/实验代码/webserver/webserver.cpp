#include <iostream>
#include <cstring>
#include <fstream>
#include <vector>
#include <sys/socket.h>
#include <netinet/in.h>
#include <unistd.h>
#include <pthread.h>
#include <openssl/ssl.h>
#include <openssl/err.h>

#define PORT 4433
#define BUFSIZZ 1024

struct ThreadData {
    SSL_CTX* ctx;
    int clientSocket;
};

class CHttpProtocol {
public:
    SSL_CTX *ctx;
    int m_listenSocket;

    CHttpProtocol() {
        ctx = nullptr;
        m_listenSocket = -1;
        initializeSSL();
        TcpListen();
    }

    ~CHttpProtocol() {
        if (ctx) {
            SSL_CTX_free(ctx);
        }
        if (m_listenSocket != -1) {
            close(m_listenSocket);
        }
    }

    void initializeSSL() {
        SSL_library_init();
        OpenSSL_add_all_algorithms();
        SSL_load_error_strings();
        const SSL_METHOD *meth = SSLv23_server_method();
        ctx = SSL_CTX_new(meth);
        if (!ctx) {
            std::cerr << "Could not create SSL context" << std::endl;
            exit(1);
        }
        SSL_CTX_use_certificate_chain_file(ctx, "server.pem");
        SSL_CTX_use_PrivateKey_file(ctx, "server.pem", SSL_FILETYPE_PEM);
        SSL_CTX_load_verify_locations(ctx, "root.pem", NULL);
        std::cout << "SSL initialization complete." << std::endl;
    }

    int TcpListen() {
        struct sockaddr_in addr;

        m_listenSocket = socket(AF_INET, SOCK_STREAM, 0);
        if (m_listenSocket < 0) {
            std::cerr << "Unable to create socket" << std::endl;
            exit(1);
        }

        memset(&addr, 0, sizeof(addr));
        addr.sin_family = AF_INET;
        addr.sin_port = htons(PORT);
        addr.sin_addr.s_addr = INADDR_ANY;

        if (bind(m_listenSocket, (struct sockaddr*)&addr, sizeof(addr)) < 0) {
            std::cerr << "Unable to bind" << std::endl;
            exit(1);
        }

        if (listen(m_listenSocket, 1) < 0) {
            std::cerr << "Unable to listen" << std::endl;
            exit(1);
        }

        std::cout << "Server listening on port " << PORT << std::endl;
        return m_listenSocket;
    }

    static void *ClientThread(void *data) {
        ThreadData* threadData = (ThreadData*)data;
        int client = threadData->clientSocket;
        SSL_CTX* ctx = threadData->ctx;
        SSL *ssl;
        char buf[BUFSIZZ];
        int r;

        ssl = SSL_new(ctx);
        SSL_set_fd(ssl, client);

        if (SSL_accept(ssl) <= 0) {
            ERR_print_errors_fp(stderr);
        } else {
            std::cout << "SSL handshake completed." << std::endl;
            r = SSL_read(ssl, buf, sizeof(buf) - 1);
            if (r > 0) {
                buf[r] = '\0';
                std::cout << "Received: " << buf << std::endl;

                std::string request(buf);
                size_t pos = request.find("GET ");
                if (pos != std::string::npos) {
                    size_t start = pos + 4;
                    size_t end = request.find(" ", start);
                    std::string url = request.substr(start, end - start);
                    std::cout << "Handling GET request for: " << url << std::endl;

                    std::string filepath = "." + url;  // Use current directory
                    std::ifstream file(filepath, std::ios::binary | std::ios::ate);
                    if (file.is_open()) {
                        std::streamsize size = file.tellg();
                        file.seekg(0, std::ios::beg);

                        std::vector<char> buffer(size);
                        if (file.read(buffer.data(), size)) {
                            std::string response = "HTTP/1.1 200 OK\r\nContent-Type: ";
                            response += (filepath.find(".jpg") != std::string::npos) ? "image/jpeg" : "text/html";
                            response += "\r\n\r\n";
                            SSL_write(ssl, response.c_str(), response.length());
                            SSL_write(ssl, buffer.data(), size);
                        }
                        file.close();
                    } else {
                        std::string response = "HTTP/1.1 404 Not Found\r\nContent-Type: text/html\r\n\r\n<html><body><h1>404 Not Found</h1></body></html>";
                        SSL_write(ssl, response.c_str(), response.length());
                    }
                }
            }
        }

        SSL_shutdown(ssl);
        SSL_free(ssl);
        close(client);
        delete threadData;
        return nullptr;
    }

    void StartHttpSrv() {
        struct sockaddr_in addr;
        socklen_t len = sizeof(addr);
        int client;

        while ((client = accept(m_listenSocket, (struct sockaddr*)&addr, &len)) != -1) {
            pthread_t tid;
            ThreadData* threadData = new ThreadData{ctx, client};
            pthread_create(&tid, NULL, ClientThread, (void*)threadData);
            pthread_detach(tid);
        }
    }
};

int main() {
    CHttpProtocol server;
    server.StartHttpSrv();

    return 0;
}
